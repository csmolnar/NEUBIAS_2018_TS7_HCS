clear all;

warning off all;

% CellProfiler pipeline name
pipeLineName = 'S8_SCREEN_PIPE_20171115_spot_detection_oversegmentation.mat';

% number of CPUs working parallel
poolSize = 4;

% number of images in each batch
batchSize = 8;

% number of new attempts if a processes fails
numAttempts = 4;

mainFolder = 'd:\Projects\S8 SCREEN\plates\';

plateList = dir(fullfile(mainFolder, '100119*'));

% filter only on directories
plateList(~cat(1,plateList.isdir)) = [];

for i=1:numel(plateList)

    folderName = fullfile(mainFolder, plateList(i).name);
    failedJobs = evalBatch(folderName, pipeLineName, poolSize, batchSize, numAttempts);

end
